HOMEWORK 4: STENCIL BUFFER & GLSL SHADERS

NAME:  < insert name >



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



COLLABORATORS AND OTHER RESOURCES: List the names of everyone you
talked to about this assignment and all of the resources (books,
online reference material, etc.) you consulted in completing this
assignment.

MIRROR RENDERING:
< insert comments on the implementation, known bugs, discussion of
lighting artifacts & fixes for extra credit >



SHADOW VOLUMES:
< insert comments on the implementation, known bugs, extra credit >



GLSL SHADERS: 
< insert comments on the implementation, command line to run your new
shader(s), sample output, known bugs, extra credit >



OTHER NEW FEATURES OR EXTENSIONS FOR EXTRA CREDIT:
< include instructions for use and test cases and sample output as
appropriate >
